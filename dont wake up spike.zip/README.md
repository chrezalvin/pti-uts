# UTS Pengantar Teknologi Informatika Kelompok 9
 UTS Project Website (IF231-AL) Intro to Internet Technology LEC & LAB

## Anggota Kelompok
 - Chrealvin (00000045606)
 - Tristan Liandra Amatya (00000089615)
 - Bisara Wahyu Diwangga (00000063627)
 - Stephen Tanuwijaya (00000042628)
 
 ## Aturan Permainan
  - 
 
